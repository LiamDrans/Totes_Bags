"""template for future"""
def lambda_handler(event, context):
    """template for future"""
    return (event,context)
