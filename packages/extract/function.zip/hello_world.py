"""Simple test file for CI/CD pipeline. check for teeraform update v2"""

def hello_world():
    """Return the string 'Hello, World!'."""
    print('Hello World!')
    return 'Hello, World!'
